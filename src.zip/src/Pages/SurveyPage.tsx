import { useState } from "react";
import { Link } from "react-router-dom";
import AuthLayout from "../components/BackgroundLayout";

const options = ["Hitam", "Hitam", "Hitam", "Hitam"];

export default function Quiz() {
  const [selected, setSelected] = useState<number | null>(null);

  return (
    <AuthLayout>
      <h2 className="text-lg font-semibold">Question 1</h2>
      <hr className="my-2 border-t-2 border-gray-200" />
      <p className="text-gray-700 mb-4">
        How often have you felt stressed in the past week?
      </p>

      <div className="space-y-4">
        {options.map((option, index) => (
          <label
            key={index}
            className={`flex items-center p-4 rounded-xl cursor-pointer border transition-all ${
              selected === index
                ? "bg-blue-500 text-white border-blue-500"
                : "bg-gray-100 border-gray-300"
            }`}
            onClick={() => setSelected(index)}
          >
            <span
              className={`w-6 h-6 flex justify-center items-center rounded-full border ${
                selected === index
                  ? "bg-blue-600 text-white border-blue-600"
                  : "border-gray-400"
              } mr-3`}
            >
              {String.fromCharCode(65 + index)}
            </span>
            {option}
          </label>
        ))}
      </div>

      <Link to="/user-survey">
        <Button className="mt-6 px-6 py-2 bg-blue-500 text-white rounded-xl flex items-center gap-2">
          Next <span className="text-lg">→</span>
        </Button>
      </Link>
    </AuthLayout>
  );
}
export default SurveyPage;
