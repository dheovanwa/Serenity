import React from "react";
import ManageAppointmentContent from "../components/ManageAppointmentContent";


const ManageApt = () => {
  return (
    
      <ManageAppointmentContent />
    
  );
};

export default ManageApt;