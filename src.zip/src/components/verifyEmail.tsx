import VerifPage from "./verifyEmailSent";

const Verif = () => {
  return <VerifPage />;
};

export default Verif;
