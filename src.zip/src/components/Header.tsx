import React from "react";

const Header = () => {
  return <header style={styles.header}></header>;
};
